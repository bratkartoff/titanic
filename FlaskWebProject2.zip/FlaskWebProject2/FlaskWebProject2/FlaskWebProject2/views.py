"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template
from FlaskWebProject2 import app
from flask import jsonify
from flask import json

@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )
  

@app.route('/Logs')
def contact():
    return render_template(
        'logs.html',
        title='DataLogs',
        year=datetime.now().year,
        message='Logged Data'
    )


@app.route('/TimeCourse')
def course():
    return render_template(
        'TimeCourse.html',
        title='DataLogs',
        year=datetime.now().year,
        message='Logged Data'
    )


@app.route('/about')
def about():
    """Renders the about page."""
    X_CORD=str(43.471422)
    Y_CORD=str(13.074839)
    return render_template(
        'about.html',
        title='About',
        MAPLINK="https"+"://maps.google.com/maps?q="+X_CORD+"%2C"+X_CORD+"&t=&z=18&ie=UTF8&iwloc=&output=embed",#"https://maps.google.com/maps?q="+X_CORD+","+Y_CORD+"&hl=es;z=14&amp;output=embed",
        year=datetime.now().year,
        message='Your application description page.'
    )
