"""
Routes and views for the flask application.
"""

from datetime import datetime
from FlaskWebProject2 import app
from flask import jsonify
from flask import json
import io
import random
import pandas as pd
import numpy as np
from flask import Response, Flask, render_template
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib import pyplot as plt
import matplotlib as mpl


@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    X_CORD=str(43.471422)
    Y_CORD=str(13.074839)
    return render_template(
        'about.html',
        title='About',
        MAPLINK="https"+"://maps.google.com/maps?q="+X_CORD+"%2C"+X_CORD+"&t=&z=18&ie=UTF8&iwloc=&output=embed",#"https://maps.google.com/maps?q="+X_CORD+","+Y_CORD+"&hl=es;z=14&amp;output=embed",
        year=datetime.now().year,
        message='Your application description page.'
    )
  

@app.route('/Logs')
def logs():
    return render_template(
        'logs.html',
        title='DataLogs',
        year=datetime.now().year,
        message='Logged Data'
    )


@app.route('/timeCourse')
def course():
    return render_template(
        'TimeCourse.html',
        title='DataLogs',
        year=datetime.now().year,
        message='Logged Data'
    )


@app.route('/status')
def status():
    """Renders the about page."""
    data = pd.read_csv("data.csv")
    data = data.tail(1) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
   
    for x in data["gps_l"]:
       X_CORD = x
    for y in data["gps_b"]:
       Y_CORD = y
    X_CORD=str(X_CORD)
    #X_CORD = '\'' + X_CORD + '\''
    Y_CORD=str(Y_CORD)
    #Y_CORD = '\'' + Y_CORD + '\''
    #print("X:", X_CORD)
    #print("Y:", Y_CORD)
    #print("DEBUG YCORD:", Y_CORD)
    return render_template(
        'about.html',
        title='About',
        #MAPLINK="https"+"://maps.google.com/maps?q="+X_CORD+"E"+Y_CORD+"N&t=&z=18&ie=UTF8&iwloc=&output=embed",#"https://maps.google.com/maps?q="+X_CORD+","+Y_CORD+"&hl=es;z=14&amp;output=embed",
        MAPLINK="https"+"://maps.google.com/maps?q="+X_CORD+"E"+Y_CORD+"N",
        year=datetime.now().year,
        message='Your application description page.'
    )


@app.route('/watertemp') #todo rm
def akt1():
    #return '<img src="plot.png" id="myImage" />'
    return render_template('reload_frame.html', picture_path = "plots/water_temp.png")

@app.route('/airtemp') #todo rm
def akt2():
    #return '<img src="plot.png" id="myImage" />'
    return render_template('reload_frame.html', picture_path = "plots/air_temp.png")


plt.style.use('seaborn')


@app.route('/plots/air_humi.png')
def plot_png_0():
    fig = create_figure_0()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_0():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["air_humi"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('rel. Humidity in %')
    axis.plot(xs, ys)
    return fig

@app.route('/plots/air_pres.png')
def plot_png_1():
        fig = create_figure_1()
        output = io.BytesIO()
        FigureCanvas(fig).print_png(output)
        return Response(output.getvalue(),  mimetype='image/png')

def create_figure_1():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["air_pres"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('Pressure [HPa]')
    axis.plot(xs, ys)
    return fig



@app.route('/plots/air_temp.png')
def plot_png_2():
    fig = create_figure_2()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_2():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["air_temp"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('Air Temperature in C')
    axis.plot(xs, ys)
    return fig



@app.route('/plots/water_temp.png')
def plot_png_3():
    fig = create_figure_3()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_3():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["water_temp"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('Water Temperature [C°]')
    axis.plot(xs, ys)
    return fig



@app.route('/plots/water_ph.png')
def plot_png_4():
    fig = create_figure_4()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_4():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["water_pH"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('ph')
    axis.plot(xs, ys)
    return fig
