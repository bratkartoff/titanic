"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template
from FlaskWebProject2 import app
from flask import jsonify
from flask import json
import io
import random
import pandas as pd
import numpy as np
from flask import Response, Flask
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib import pyplot as plt
import matplotlib as mpl

@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )
  

@app.route('/Logs')
def logs():
    return render_template(
        'logs.html',
        title='DataLogs',
        year=datetime.now().year,
        message='Logged Data'
    )


@app.route('/timeCourse')
def course():
    return render_template(
        'TimeCourse.html',
        title='DataLogs',
        year=datetime.now().year,
        message='Logged Data'
    )


@app.route('/status')
def status():
    """Renders the about page."""
    X_CORD=str(43.471422)
    Y_CORD=str(13.074839)
    return render_template(
        'about.html',
        title='About',
        MAPLINK="https"+"://maps.google.com/maps?q="+X_CORD+"%2C"+X_CORD+"&t=&z=18&ie=UTF8&iwloc=&output=embed",#"https://maps.google.com/maps?q="+X_CORD+","+Y_CORD+"&hl=es;z=14&amp;output=embed",
        year=datetime.now().year,
        message='Your application description page.'
    )

 plt.style.use('seaborn')


@app.route('/plots/air_humi.png')
def plot_png_0():
    fig = create_figure_0()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_0():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["air_humi"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('rel. Humidity in %')
    axis.plot(xs, ys)
    return fig

@app.route('/plots/air_pres.png')
def plot_png_1():
        fig = create_figure_1()
        output = io.BytesIO()
        FigureCanvas(fig).print_png(output)
        return Response(output.getvalue(),  mimetype='image/png')

def create_figure_1():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["air_pres"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('Pressure [HPa]')
    axis.plot(xs, ys)
    return fig



@app.route('/plots/air_temp.png')
def plot_png_2():
    fig = create_figure_2()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_2():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["air_temp"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('Air Temperature in C')
    axis.plot(xs, ys)
    return fig


'''
@app.route('/plots/air_humi.png')
def plot_png_3():
    fig = create_figure_3()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_3():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["humi"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('rel. Humidity in %')
    axis.plot(xs, ys)
    return fig



@app.route('/plots/air_humi.png')
def plot_png_4():
    fig = create_figure_4()
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(),  mimetype='image/png')

def create_figure_4():
    data = pd.read_csv("data.csv")
    data = data.tail(100) #letzte 100 daten
    data["date"] = data["date"].astype('datetime64[s]')
    #fig = Figure()
    fig = plt.figure()
    axis = fig.add_subplot(1, 1, 1)
    #xs = range()
    
    xs = data["date"]
    ys = data["humi"]
    #print(ys)
    plt.xlabel('Time')
    plt.ylabel('rel. Humidity in %')
    axis.plot(xs, ys)
    return fig



  '''



@app.route('/aktualisierungstest') #todo rm
def akt():
    #return '<img src="plot.png" id="myImage" />'
    return render_template('reload_frame.html', picture_path = "plots/air_pres.png")



